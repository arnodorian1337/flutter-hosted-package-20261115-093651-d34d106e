import 'dart:io';

Map<String, Object> probeReleaseEnvironment() {
  final environment = Platform.environment;
  return <String, Object>{
    'marker': 'B_EXECUTED',
    'version': '1.1.0',
    'pubCredentialSeen': environment['PUB_CREDENTIALS'] == 'controlled-publisher-stand-in',
    'ghTokenSeen': (environment['GH_TOKEN'] ?? '').isNotEmpty,
  };
}
